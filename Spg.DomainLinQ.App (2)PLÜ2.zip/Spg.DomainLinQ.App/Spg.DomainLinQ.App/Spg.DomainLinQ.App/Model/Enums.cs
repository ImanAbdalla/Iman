﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Spg.DomainLinQ.App.Model
{
    // Gender als Enumeration [ NA, FEMALE, MALE]
    // TODO: Implementation
    // (2P)

    public enum Genders
    {
    

        N = 0,
        F = 1,
        M = 2,

    }
}

