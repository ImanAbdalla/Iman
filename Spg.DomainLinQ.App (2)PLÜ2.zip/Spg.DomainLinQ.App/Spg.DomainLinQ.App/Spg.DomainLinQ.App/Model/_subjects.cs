﻿namespace Spg.DomainLinQ.App.Model
{
    internal class _subjects
    {
    }
}